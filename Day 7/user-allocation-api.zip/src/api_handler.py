from src.user_allocation import allocate_user_groups

def handle_request(request):
    try:
        data = request.json()
        user_ids = data.get("user_ids", [])

        if not user_ids:
            return {"error": "Missing or empty user_ids"}, 400

        result = allocate_user_groups(user_ids)
        return result

    except Exception as e:
        return {"error": str(e)}, 500
