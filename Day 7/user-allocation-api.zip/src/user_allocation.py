from transforms.api import get_dataset

def allocate_user_groups(user_ids: list):
    ds = get_dataset("foundry_workspace/datasets/user_profiles")
    df = ds.dataframe()

    results = []

    for uid in user_ids:
        user = df[df["user_id"] == uid]
        if user.empty:
            results.append({"user_id": uid, "error": "User not found"})
        else:
            u = user.iloc[0].to_dict()
            group = "Group A" if uid % 2 == 0 else "Group B"
            results.append({
                "user_id": u["user_id"],
                "name": u["name"],
                "email": u["email"],
                "group": group
            })

    return results
