from src.user_allocation import allocate_user_groups

def transform(ctx, df):
    user_ids = df["user_id"].tolist()
    import pandas as pd
    return pd.DataFrame(allocate_user_groups(user_ids))
