from src.user_allocation import allocate_user_groups
import pandas as pd
from datetime import datetime

def transform(ctx, df):
    user_ids = df["user_id"].tolist()
    enriched = allocate_user_groups(user_ids)

    for record in enriched:
        record["allocation_time"] = datetime.utcnow().isoformat()

    return pd.DataFrame(enriched)
