from transforms.api import get_dataset

def allocate_user_groups(user_ids: list):
    ds = get_dataset("foundry_workspace/datasets/user_profiles")
    df = ds.dataframe()

    results = []

    for uid in user_ids:
        user = df[df["user_id"] == uid]
        if user.empty:
            results.append({"user_id": uid, "error": "User not found"})
        else:
            u = user.iloc[0].to_dict()
            dept = u.get("department", "").lower()
            if dept == "engineering":
                group = "Tech Group"
            elif dept == "sales":
                group = "Revenue Group"
            else:
                group = "General Group"

            results.append({
                "user_id": u["user_id"],
                "name": u["name"],
                "email": u["email"],
                "department": u.get("department"),
                "group": group
            })

    return results

def override_user_groups(user_ids: list[int], overrides: dict[int, str]) -> list[dict]:
    users = allocate_user_groups(user_ids)
    for user in users:
        uid = user["user_id"]
        if uid in overrides:
            user["group"] = overrides[uid]
            user["overridden"] = True
        else:
            user["overridden"] = False
    return users
